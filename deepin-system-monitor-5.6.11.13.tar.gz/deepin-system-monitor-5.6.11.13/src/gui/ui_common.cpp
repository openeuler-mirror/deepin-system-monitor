#include <QGraphicsDropShadowEffect>
#include <QGraphicsEffect>

#include "ui_common.h"
