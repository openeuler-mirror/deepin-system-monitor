<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bg">
<context>
    <name>App.About</name>
    <message>
        <source>System Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Monitor is a tool to monitor realtime system load, view and control processes and services running on your system.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Common.Search</name>
    <message>
        <source>No search results</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DBus.Unit.Active.State</name>
    <message>
        <source>active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>reloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>activating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deactivating</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DBus.Unit.Load.State</name>
    <message>
        <source>stub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>not-found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>bad-setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>merged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>masked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DBus.Unit.Startup.Mode</name>
    <message>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DBus.Unit.State</name>
    <message>
        <source>enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>static</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>transient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>indirect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>enabled-runtime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>masked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>generated</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DBus.Unit.Sub.State</name>
    <message>
        <source>dead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>start-pre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>start-post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>exited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop-watchdog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop-sigterm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop-sigkill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop-post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>final-sigterm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>final-sigkill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>auto-restart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Error.Dialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Help.Shortcut.System</name>
    <message>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Kill.Process.Dialog</name>
    <message>
        <source>Ending this process may cause data loss.
Are you sure you want to continue?</source>
        <translation type="unfinished">Прекратяването на този процес може да причини загуба на данни.
Сигурни ли сте, че искате да продължите? </translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Отказ</translation>
    </message>
    <message>
        <source>End process</source>
        <translation type="unfinished">Край на процес</translation>
    </message>
    <message>
        <source>Force ending this process may cause data loss.
Are you sure you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force ending this application may cause data loss.
Are you sure you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force End</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Attributes.Dialog</name>
    <message>
        <source>Command line</source>
        <translation type="unfinished">Команден ред</translation>
    </message>
    <message>
        <source>Start time</source>
        <translation type="unfinished">Време на стартиране</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Име</translation>
    </message>
</context>
<context>
    <name>Process.Choose.Window.Dialog</name>
    <message>
        <source>Click the application you want to end</source>
        <translation type="unfinished">Кликнете на приложението, което искате да спрете</translation>
    </message>
</context>
<context>
    <name>Process.Graph.Title</name>
    <message>
        <source>Memory</source>
        <translation type="unfinished">Памет</translation>
    </message>
</context>
<context>
    <name>Process.Graph.View</name>
    <message>
        <source>CPU</source>
        <translation type="unfinished">Процесор</translation>
    </message>
    <message>
        <source>Disk read</source>
        <translation type="unfinished">Четене на диска</translation>
    </message>
    <message>
        <source>Disk write</source>
        <translation type="unfinished">Запис на диска</translation>
    </message>
    <message>
        <source>Memory</source>
        <translation type="unfinished">Памет</translation>
    </message>
    <message>
        <source>Swap</source>
        <translation type="unfinished">Swap</translation>
    </message>
    <message>
        <source>Not enabled</source>
        <translation type="unfinished">Не е разрешено</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished">Сваляне</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation type="unfinished">Качване</translation>
    </message>
    <message>
        <source>Disk</source>
        <translation type="unfinished">Диск</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished">Мрежа</translation>
    </message>
    <message>
        <source>Total Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Sent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Priority</name>
    <message>
        <source>Very high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PID: %1, Error: [%2] %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to change process priority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Show.Mode</name>
    <message>
        <source>Applications</source>
        <translation type="unfinished">Приложения</translation>
    </message>
    <message>
        <source>My processes</source>
        <translation type="unfinished">Моите процеси</translation>
    </message>
    <message>
        <source>All processes</source>
        <translation type="unfinished">Всички процеси</translation>
    </message>
</context>
<context>
    <name>Process.Signal</name>
    <message>
        <source>Failed to pause process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to resume process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to kill process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed in sending signal to process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to end process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Summary</name>
    <message>
        <source>(%1 applications and %2 processes are running)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Table</name>
    <message>
        <source>No response</source>
        <translation type="unfinished">Няма отговор</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation type="unfinished">Приспиване</translation>
    </message>
    <message>
        <source>Tray</source>
        <translation type="unfinished">Лента на задачи</translation>
    </message>
</context>
<context>
    <name>Process.Table.Context.Menu</name>
    <message>
        <source>View command location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished">Свойства</translation>
    </message>
    <message>
        <source>End process</source>
        <translation type="unfinished">Край на процес</translation>
    </message>
    <message>
        <source>Resume process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kill process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suspend process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Table.Custom.Priority.Dialog</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Отказ</translation>
    </message>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Priority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Process.Table.Header</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Име</translation>
    </message>
    <message>
        <source>CPU</source>
        <translation type="unfinished">Процесор</translation>
    </message>
    <message>
        <source>Memory</source>
        <translation type="unfinished">Памет</translation>
    </message>
    <message>
        <source>Disk write</source>
        <translation type="unfinished">Запис на диска</translation>
    </message>
    <message>
        <source>Disk read</source>
        <translation type="unfinished">Четене на диска</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished">Сваляне</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation type="unfinished">Качване</translation>
    </message>
    <message>
        <source>PID</source>
        <translation type="unfinished">PID</translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Swap</source>
        <translation type="vanished">Swap</translation>
    </message>
    <message>
        <source>Not enabled</source>
        <translation type="vanished">Не е разрешено</translation>
    </message>
</context>
<context>
    <name>Service.Action.Set.Startup.Mode</name>
    <message>
        <source>Failed to set service startup type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Failed to set service startup type due to the crashed sub process.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Service.Instance.Name.Dialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Отказ</translation>
    </message>
    <message>
        <source>Service instance name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Service.Table.Context.Menu</name>
    <message>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Startup type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Service.Table.Header</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Име</translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub</source>
        <extracomment>sub state (running status)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <extracomment>state</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PID</source>
        <translation type="unfinished">PID</translation>
    </message>
    <message>
        <source>Startup Type</source>
        <extracomment>service startup mode</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Title.Bar.Context.Menu</name>
    <message>
        <source>Force end application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Title.Bar.Search</name>
    <message>
        <source>Search</source>
        <translation type="unfinished">Търсене</translation>
    </message>
</context>
<context>
    <name>Title.Bar.Switch</name>
    <message>
        <source>Processes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
