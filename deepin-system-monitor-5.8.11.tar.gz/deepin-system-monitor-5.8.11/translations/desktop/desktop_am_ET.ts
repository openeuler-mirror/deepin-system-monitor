<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="am_ET"><context><name>desktop</name><message><location filename="Desktop Entry]Name" line="0"/><source>Deepin System Monitor</source><translation>ዲፕኢን ስርአት መቆጣጠሪያ</translation></message><message><location filename="Desktop Entry]Comment" line="0"/><source>Monitor system process status</source><translation>የ ስርአቱን ሂደት ሁኔታ መቆጣጠሪያ</translation></message><message><location filename="Desktop Entry]GenericName" line="0"/><source>System Monitor</source><translation>ስርአት መቆጣጠሪያ</translation></message></context></TS>
