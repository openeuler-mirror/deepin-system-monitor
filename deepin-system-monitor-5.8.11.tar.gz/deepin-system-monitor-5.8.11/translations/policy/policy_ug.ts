<?xml version="1.0" ?><!DOCTYPE TS><TS language="ug" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>جەرياننىڭ مۇھىملىق دەرجىسىنى ئۆزگەرتىش ئۈچۈن دەلىللەش تەلەپ قىلىنىدۇ</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>قايتا قۇرۇش جەريانى</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>باشقا ئىشلەتكۈچىلەرنىڭ جەريانلىرىنى كونترول قىلىش ئۈچۈن دەلىللەش تەلەپ قىلىنىدۇ</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>جەرياننى ئۆلتۈرۈش</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>مۇلازىمەت باشلاش تىپىنى تەڭشەش ئۈچۈن دەلىللەش تەلەپ قىلىنىدۇ</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>مۇلازىمەت باشلاش تىپىنى بەلگىلەش</translation>
		</message>
	</context>
</TS>