<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>改变进程优先级需要认证</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>更改进程nice值</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>控制其他用户的进程需要认证</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>强制结束进程</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>设置服务的启动方式需要认证</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>设置服务的启动方式</translation>
		</message>
	</context>
</TS>