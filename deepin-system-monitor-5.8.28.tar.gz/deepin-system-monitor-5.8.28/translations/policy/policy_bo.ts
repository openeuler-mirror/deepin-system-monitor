<?xml version="1.0" ?><!DOCTYPE TS><TS language="bo" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>བརྒྱུད་རིམ་གྱི་སྔོན་རིམ་བསྒྱུར་བར་དཔང་དཔྱད་བྱ་དགོས།</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>བརྒྱུད་རིམ་niceགྲངས་ཐང་བསྒྱུར་དགོས།</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>སྤྱོད་མཁན་གཞན་དག་གི་བརྒྱུད་རིམ་ཚོད་འཛིན་བྱེད་པར་དཔང་དཔྱད་བྱ་དགོས།</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>བཙན་ཐབས་ཀྱིས་བརྒྱུད་རིམ་མཇུག་སྒྲིལ་བ།</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>ཞབས་ཞུའི་འགོ་སློང་ཐབས་སྒྲིག་འགོད་བྱེད་པར་དཔང་དཔྱད་བྱ་དགོས།</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>ཞབས་ཞུའི་འགོ་སློང་བྱེད་ཐབས་སྒྲིག་འགོད་བྱེད་པ།</translation>
		</message>
	</context>
</TS>