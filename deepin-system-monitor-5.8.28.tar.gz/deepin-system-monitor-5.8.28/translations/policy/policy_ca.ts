<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>Cal autenticació per canviar la prioritat del procés.</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>Reinicia el procés</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>Cal autenticació per controlar els processos d&apos;altres usuaris.</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>Mata el procés</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>Cal autenticació per establir el tipus d&apos;inici del servei.</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>Establiu el tipus d&apos;inici del servei</translation>
		</message>
	</context>
</TS>