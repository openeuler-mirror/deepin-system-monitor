<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS language="ca@valencia" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0" />
			<source>Authentication is required to change process priority</source>
			<translation type="unfinished" />
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0" />
			<source>Renice process</source>
			<translation type="unfinished" />
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0" />
			<source>Authentication is required to control other users' processes</source>
			<translation type="unfinished" />
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0" />
			<source>Kill process</source>
			<translation type="unfinished" />
		</message>
	</context>
</TS>
