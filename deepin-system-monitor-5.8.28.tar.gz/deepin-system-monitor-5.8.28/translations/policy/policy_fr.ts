<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>Une authentification est requise pour modifier la priorité du processus</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>Processus Renice</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>L&apos;authentification est requise pour contrôler les processus des autres utilisateurs</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>Tuer le processus</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>L&apos;authentification est requise pour définir le type de démarrage du service</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>Définir le type de démarrage du service</translation>
		</message>
	</context>
</TS>