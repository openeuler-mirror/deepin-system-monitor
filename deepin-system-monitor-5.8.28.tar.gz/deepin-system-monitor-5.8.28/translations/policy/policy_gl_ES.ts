<?xml version="1.0" ?><!DOCTYPE TS><TS language="gl_ES" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>A autenticación é necesaria para cambiar a prioridade do proceso</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>Proceso de Renice</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>A autenticación é necesaria para controlar os procesos doutros usuarios</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>Proceso de Kill</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>A autenticación é necesaria para configurar o tipo de inicio de servizo</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>Estableza o tipo de inicio de servizo</translation>
		</message>
	</context>
</TS>