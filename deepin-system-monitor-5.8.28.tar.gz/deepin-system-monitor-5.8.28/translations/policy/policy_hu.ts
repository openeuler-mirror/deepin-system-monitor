<?xml version="1.0" ?><!DOCTYPE TS><TS language="hu" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!message" line="0"/>
			<source>Authentication is required to change process priority</source>
			<translation>Hitelesítés szükséges a folyamat prioritásának megváltoztatásához</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.renice!description" line="0"/>
			<source>Renice process</source>
			<translation>Renice folyamat</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!message" line="0"/>
			<source>Authentication is required to control other users&apos; processes</source>
			<translation>Hitelesítés szükséges a többi felhasználó folyamatainak vezérléséhez</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.kill!description" line="0"/>
			<source>Kill process</source>
			<translation>Folyamat kilövése</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!message" line="0"/>
			<source>Authentication is required to set service startup type</source>
			<translation>Hitelesítés szükséges a szolgáltatás indítási típusának beállításához</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-system-monitor.systemctl!description" line="0"/>
			<source>Set service startup type</source>
			<translation>Állítsa be a szolgáltatás indítási típusát</translation>
		</message>
	</context>
</TS>